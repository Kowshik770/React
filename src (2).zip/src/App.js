import logo from './logo.svg';
import './App.css';

import CreateBooks from "./Books/CreateBooks";
import DeleteBooks from "./Books/DeleteBooks";
import UpdateBooks from "./Books/UpdateBooks";
import SearchBooks from "./Books/SearchBooks";
import ShowAllBooks from "./Books/ShowAllBooks";
import {BrowserRouter,Routes,Route,Link} from "react-router-dom";



function App() {
  return (
    <BrowserRouter>
    <div className="App">
      <ul>
        <li><Link to="/" >ShowAllBooks</Link>   </li>  
        <li><Link to="/CreateBooks">CreateBooks</Link>   </li>  
        <li><Link to="/DeleteBooks">DeleteBooks</Link>   </li>  
        <li><Link to="/UpdateBooks">UpdateBooks</Link>   </li>  
        <li><Link to="/SearchBooks">SearchBooks</Link>   </li>  
      
      </ul>
      <Routes>
        <Route path='/' element={<ShowAllBooks/>}></Route>
        <Route path='/CreateBooks' element={<CreateBooks/>}></Route>
        <Route path='/DeleteBooks' element={<DeleteBooks/>}></Route>
        <Route path='/UpdateBooks' element={<UpdateBooks/>}></Route>
        <Route path='/SearchBooks' element={<SearchBooks/>}></Route>
      </Routes>
    
    </div>
    </BrowserRouter>
  );
}

export default App;
