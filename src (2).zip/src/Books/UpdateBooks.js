import React, { Component } from 'react'
import axios from 'axios';

export default class UpdateBooks extends Component {
    constructor()
    {
        super();
        this.state={
            id:'',
            title:'',
            description:''
        }
        this.UpdateBooks=this.UpdateBooks.bind(this);
    }
    UpdateBooks()
    {
        let id=this.state.id;
        let url="https://localhost:44320/api/Books/"+id;
        axios.put(url,{
            title:this.state.title,
            description:this.state.description
        }).then(response=>{
            alert("data Updated");
        }).catch(error=>{
            alert(error);
        })
    window.location="./";
    }
    handleChange(ChangeObject){
        this.setState(ChangeObject);
    
    }

  render() {
    return (
      <><div>UpdateBooks</div><><div>CreateBooks</div><table className='t' border="1" align="center">
            <tr>
                <td><label>Book Id</label> </td>
                <td><input type="text" name="id" onChange={(e) => this.handleChange({ id: e.target.value })}></input> </td>
            </tr>
            <tr>
                <td><label>Book Title</label> </td>
                <td><input type="text" name="title" onChange={(e) => this.handleChange({ title: e.target.value })}></input> </td>
            </tr>
            <tr>
                <td><label>Book Description</label> </td>
                <td><input type="text" name="description" onChange={(e) => this.handleChange({ description: e.target.value })}></input> </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <button type="button" onClick={this.UpdateBooks}>Update</button>

                </td>
            </tr>
        </table></></>
 
    )
  }
}
