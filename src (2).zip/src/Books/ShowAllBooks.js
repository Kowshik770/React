import React, { Component } from 'react'
import axios from 'axios';

export default class ShowAllBooks extends Component {
    constructor()
    {
        super();
        this.state={
            Books:[]
        }
    }
refereshList()
{
    let url="https://localhost:44320/api/Books";
    axios.get(url).then(response=>{
        this.setState({Books:response.data})
    }).catch(error=>{
        console.warn(error);
    })
}
componentDidMount()
{
    this.refereshList();
}

  render() {
    const {Books}=this.state;
    return (
      <><div>ShowAllBooks</div><div>
            <table className='t' border="1" align='center'>
                <tr>
                    <th>Book id</th>
                    <th>Book Title</th>
                    <th>Book Description</th>
                </tr>
                {Books.map(a => <tr>
                    <td>{a.id}</td>
                    <td>{a.title}</td>
                    <td>{a.description}</td>
                </tr>
                )}
            </table>
        </div></>
    )
  }
}
