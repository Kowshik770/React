import axios from 'axios';
import React, { Component } from 'react'

export default class SearchBooks extends Component {
    constructor()
{
    super();
    this.state={
        id:'',
        title:'',
        description:''
    }
    this.SearchBook=this.SearchBook.bind(this);
}
SearchBook()
{
    let id=this.state.id;
    let url="https://localhost:44320/api/Books/"+id;
    axios.get(url).then(response=>{
        this.setState({
            id:response.data.id,
            title:response.data.title,
            description:response.data.description
        })
    }).catch(error=>{
        console.warn(error);
    })

}
handleChange(ChangeObject){
    this.setState(ChangeObject);

}
  render() {
    const{id}=this.state;
    const{title}=this.state;
    const{description}=this.state;
    return (
      <><div>SearchBooks</div><table className='t' border="1" align="center">
            <tr>
                <td><label>Book Id</label> </td>
                <td><input type="text" name="id" onChange={(e) => this.handleChange({ id: e.target.value })}></input> </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <button type="button" onClick={this.SearchBook}>Search</button>

                </td>
            </tr>
        </table>
        <div>
            Id={this.state.id}
            Title={title}
            Description={description}<br></br>
            description=
            <input type="text" value={this.state.description}></input>
        </div>
        </>

    )
  }
}
