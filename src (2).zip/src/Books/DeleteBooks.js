import React, { Component } from 'react'
import axios from 'axios'

export default class DeleteBooks extends Component {
    constructor()
    {
        super();
        this.state={
            id:''
        }
        this.DeleteBooks=this.DeleteBooks.bind(this);
    }
    DeleteBooks()
    {
        //alert("del");
       let id=this.state.id;
       alert(id);
        let url="https://localhost:44320/api/Books/"+id;

        axios.delete(url).then(response=>{
            alert("delete");
        }).catch(error=>{
            alert(error);
        })
    }
  render() {
    return (
      <div>DeleteBooks
<div>
    <label >Enter the Id</label>
    <input type="text" name="id" onChange={(e)=>this.setState({id:e.target.value})}></input>
<button onClick={this.DeleteBooks}>Delete</button>
</div>

      </div>
    )
  }
}
