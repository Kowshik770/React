 import React, { Component } from 'react'
import './Crud_App.css'

export default class Crud_App extends Component {
constructor()
{   super();
    this.state={
        Books:[],
        id:'',
        title:'',
        description:''

    }
    this.create=this.create.bind(this);
    this.update=this.update.bind(this);
    this.delete=this.delete.bind(this);
}
refereshList()
{
    let url="https://localhost:44320/api/Books";
    fetch(url).then(response=>response.json()).then(result=>{
        this.setState({Books:result})

    });

}
componentDidMount()
{
    this.refereshList();
}
componentDidUpdate()
{
    this.refereshList();
}
handleChange(changeObject)
{
    this.setState(changeObject);
}

create()
{
    let url="https://localhost:44320/api/Books";
    fetch(url,
        {
            "method":"POST",
            "headers":{
                "content-type":"application/json",
                "accept":"application/json"
            },
            body:JSON.stringify({
                title:this.state.title,
                description:this.state.description
            })
        }       
        
        ).then(response=>response.json()).then(result=>{
            alert("Data Inserted");
        }).catch(err=>{
            alert(err);
            console.warn(err);
        })

}
update()
{
    let id=this.state.id;
    let url="https://localhost:44320/api/Books/"+id; 
    fetch(url,
        {
            "method":"PUT",
            "headers":{
                "content-type":"application/json",
                "accept":"application/json"
            },
            body:JSON.stringify({
                title:this.state.title,
                description:this.state.description
            })
        }       
        
        ).then(response=>response.json()).then(result=>{
            alert("Data Update");
        }).catch(err=>{
            //alert(err);
            console.warn(err);
        })

}
delete()
{
    let id=this.state.id;
    let url="https://localhost:44320/api/Books/"+id;
    fetch(url,{
        "method":"DELETE",
        "headers":{
            "content-type":"application/json",
            "accept":"application/json"

        }    }).then(response=>response.json()).then(result=>{
            alert("Data Deleted");
        }).catch(error=>{
          //  alert(error);
            console.warn(error);
        })

}


  render() {
    const {Books}=this.state;
    return (
      <div className='t'>Insert Update Delete
<form >
    <table className='t' border="1" align="center">
        <tr>
            <td><label>Book Id</label> </td>
            <td><input type="text" name="id" onChange={(e)=>this.handleChange({id:e.target.value})}  ></input> </td>
        </tr>
        <tr>
            <td><label>Book Title</label> </td>
            <td><input type="text" name="title" onChange={(e)=>this.handleChange({title:e.target.value})}  ></input> </td>
        </tr>
        <tr>
            <td><label>Book Description</label> </td>
            <td><input type="text" name="description" onChange={(e)=>this.handleChange({description:e.target.value})}  ></input> </td>
        </tr>
        <tr>
            <td></td>
            <td>
                <button type="button" onClick={this.create} >Insert</button>
                <button type="button" onClick={this.update} >Update</button>
                <button type="button" onClick={this.delete} >Delete</button>
            </td>
        </tr>
    </table>
    <div>
        <table  className='t' border="1" align='center'>
            <tr>
                <th>Book id</th>
                <th>Book Title</th>
                <th>Book Description</th>
            </tr>
            {
                Books.map(a=>
                    <tr>
                        <td>{a.id}</td>
                        <td>{a.title}</td>
                        <td>{a.description}</td>
                    </tr>
                    )
            }
        </table>
    </div>
</form>



      </div>
    )
  }
}
