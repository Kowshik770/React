import React, { Component } from 'react'
// import Button from 'react-bootstrap/Button';
// import Stack from 'react-bootstrap/Stack';
import { Button,Stack } from 'react-bootstrap';
 
export default class AboutUs extends Component {
  render() {
    return (
      <><div>Aboutus</div><Stack direction="horizontal" gap={2}>
            <Button as="a" variant="primary">
                Button as link
            </Button>
            <Button as="a" variant="success">
                Button as link
            </Button>
        </Stack></>
    )
  }
}