import logo from './logo.svg';
import './App.css';
import Login from './Services/Login';
import {BrowserRouter, Link, Routes, Route} from 'react-router-dom';
import Inbox from './Services/Inbox';
import Employee from './Services/Employee';


function App() {
  return (
    <div className="App">

         {/* <Login/> */}
         <BrowserRouter>
         <Routes>
          <Route path='/' element={<Login/>}/>
          <Route path='/Inbox' element={<Inbox/>}/>
          <Route path='/Employee' element={<Employee/>}/>


         </Routes>
         </BrowserRouter>

    </div>
  );
}

export default App;
