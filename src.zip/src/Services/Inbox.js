import React, { Component } from 'react'

export default class Inbox extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         
      }
      this.logout=this.logout.bind(this);
      this.Employee=this.Employee.bind(this);
    }
    Employee(){

        window.location="/Employee"
    }
    logout(){
        sessionStorage.clear();
        window.location="/"

    }
    componentDidMount(){
        let emp=sessionStorage.getItem("empid");
        if(emp==null){
            alert("Please Login First");
            window.location="/"
        }
    }
  render() {
    return (
        <>
        <button onClick={this.logout} >logout </button>
        <button onClick={this.Employee} >Employee Page </button>

      <div>Inbox</div>
      </>
    )
  }
}